from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')


def capfirst(txt):
    capfirsttxt = txt.upper()
    return capfirsttxt

def removepunc(txt):
    analysed = ""
    punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
    for i in txt:
        if(i not in punctuations):
            analysed += i
    return analysed

def newlineremove(txt):
    newtxt = ""
    for i in txt:
        if(i == '\n' ):
            pass
        else:
            newtxt += i
    return newtxt

def spaceremove(txt):
    newtxt  = ""
    for i in txt:
        if(i == ' '):
            pass
        else:
            newtxt  += i
    return  newtxt

def charcount(txt):
    return len(txt)

def analyse(request):
    params  = {}
    djtext = request.POST.get('text', 'default')
    dicfuncs = {}
    dicfuncs['puncs'] = request.POST.get('puncs', 'off')
    dicfuncs['capfirst'] = request.POST.get('capfirst', 'off')
    dicfuncs['newlineremove'] = request.POST.get('newlineremove', 'off')
    dicfuncs['spaceremove'] = request.POST.get('spaceremove', 'off')
    dicfuncs['charcount'] = request.POST.get('charcount', 'off')
    lst = []
    for i in dicfuncs:
        if dicfuncs[i] == 'on':
            lst.append(i)
    for i in range(len(lst)):
        if(lst[i] == 'puncs'):
            params[lst[i]] = removepunc(djtext)
        elif(lst[i] == 'capfirst'):
            params[lst[i]] = capfirst(djtext)
        elif(lst[i] == 'newlineremove'):
            params[lst[i]] = newlineremove(djtext)
        elif(lst[i] == 'charcount'):
            params[lst[i]] = charcount(djtext)
        elif(lst[i] == 'spaceremove'):
            params[lst[i]] = spaceremove(djtext)
    return render(request,'analyse.html', params)